#!/usr/bin/env bash
# ─── RAM AI — Generate Self-Signed TLS Certs (Development) ────────────────────
# For production use: sudo certbot --nginx -d yourdomain.com

set -euo pipefail

CERT_DIR="./nginx/certs/live/ram"
mkdir -p "$CERT_DIR"

echo "[Ram] Generating self-signed TLS certificate for local development..."

openssl req -x509 \
    -nodes \
    -newkey rsa:4096 \
    -keyout "$CERT_DIR/privkey.pem" \
    -out    "$CERT_DIR/fullchain.pem" \
    -days   365 \
    -subj   "/C=US/ST=Local/L=Local/O=Ram AI/CN=localhost" \
    -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"

chmod 600 "$CERT_DIR/privkey.pem"
chmod 644 "$CERT_DIR/fullchain.pem"

echo "[Ram] ✓ TLS cert written to $CERT_DIR"
echo ""
echo "  For production, replace with Let's Encrypt:"
echo "  sudo certbot certonly --standalone -d yourdomain.com"
echo "  Then update CERT_DIR path in docker-compose.yml"
