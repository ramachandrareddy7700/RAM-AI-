# backend/routers/chat.py
"""
Chat Router
===========
POST /chat/sessions           — create new session
GET  /chat/sessions           — list all user sessions
DELETE /chat/sessions/{id}    — archive a session
POST /chat/sessions/{id}/send — send message, get response
GET  /chat/sessions/{id}/history — load decrypted history
GET  /chat/sessions/{id}/stream  — streaming response (SSE)
"""

import json
import uuid
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from crypto.key_management import get_user_key, get_master_secret
from crypto.message_crypto import RamCrypto
from db.models import Message, Session, User, UsedNonce
from db.session import get_db
from llm.ram_inference import RamLLM
from middleware.auth_middleware import get_current_user
from middleware.rate_limiter import rate_limit_user

router = APIRouter(prefix="/chat", tags=["Chat"])
llm = RamLLM()


# ── Schemas ───────────────────────────────────────────────────────────────────

class CreateSessionRequest(BaseModel):
    title: str | None = None


class SessionResponse(BaseModel):
    session_id: str
    title: str | None
    created_at: str
    updated_at: str
    message_count: int = 0


class SendMessageRequest(BaseModel):
    content: str          # plaintext from client (TLS already protects transit)
    nonce: str            # UUID4 anti-replay nonce


class MessageResponse(BaseModel):
    message_id: str
    role: str
    content: str          # decrypted content
    created_at: str


class SendResponse(BaseModel):
    user_message: MessageResponse
    assistant_message: MessageResponse
    session_id: str


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _check_nonce(nonce: str, user_id: str, db: AsyncSession):
    """Reject replayed requests."""
    existing = await db.execute(
        select(UsedNonce).where(UsedNonce.nonce == nonce)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Duplicate request detected",
        )
    db.add(UsedNonce(nonce=nonce, user_id=uuid.UUID(user_id)))


async def _load_history(
    session_id: str,
    user: User,
    db: AsyncSession,
    limit: int = 20,
) -> list[dict]:
    """Load and decrypt conversation history for LLM context."""
    result = await db.execute(
        select(Message)
        .where(
            Message.session_id == uuid.UUID(session_id),
            Message.user_id    == user.id,
        )
        .order_by(Message.created_at.desc())
        .limit(limit)
    )
    messages = list(reversed(result.scalars().all()))

    if not messages:
        return []

    user_key = await get_user_key(
        str(user.id),
        user.key_envelope,
    )

    history = []
    for msg in messages:
        try:
            content = RamCrypto.decrypt(msg.content_enc, user_key)
            history.append({"role": msg.role, "content": content})
        except Exception:
            # Skip messages that fail decryption (shouldn't happen)
            continue

    return history


async def _store_message(
    session_id: uuid.UUID,
    user: User,
    role: str,
    content: str,
    db: AsyncSession,
    user_key: bytes,
) -> Message:
    """Encrypt and persist a message."""
    content_enc = RamCrypto.encrypt(content, user_key)
    token_count = len(content) // 4  # rough estimate

    msg = Message(
        session_id=session_id,
        user_id=user.id,
        role=role,
        content_enc=content_enc,
        token_count=token_count,
    )
    db.add(msg)
    return msg


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/sessions", response_model=SessionResponse, status_code=201)
async def create_session(
    body: CreateSessionRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new chat session."""
    user_key = await get_user_key(str(current_user.id), current_user.key_envelope)

    title_enc = None
    if body.title:
        title_enc = RamCrypto.encrypt(body.title.strip()[:128], user_key)

    session = Session(
        user_id=current_user.id,
        title_enc=title_enc,
    )
    db.add(session)
    await db.commit()
    await db.refresh(session)

    return SessionResponse(
        session_id=str(session.id),
        title=body.title,
        created_at=session.created_at.isoformat(),
        updated_at=session.updated_at.isoformat(),
    )


@router.get("/sessions", response_model=list[SessionResponse])
async def list_sessions(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all sessions for the current user."""
    result = await db.execute(
        select(Session)
        .where(
            Session.user_id    == current_user.id,
            Session.is_archived == False,
        )
        .order_by(Session.updated_at.desc())
        .limit(50)
    )
    sessions = result.scalars().all()

    user_key = await get_user_key(str(current_user.id), current_user.key_envelope)

    out = []
    for s in sessions:
        title = None
        if s.title_enc:
            try:
                title = RamCrypto.decrypt(s.title_enc, user_key)
            except Exception:
                title = "Untitled"

        out.append(SessionResponse(
            session_id=str(s.id),
            title=title,
            created_at=s.created_at.isoformat(),
            updated_at=s.updated_at.isoformat(),
        ))
    return out


@router.delete("/sessions/{session_id}", status_code=204)
async def archive_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Archive (soft-delete) a session."""
    result = await db.execute(
        select(Session).where(
            Session.id      == uuid.UUID(session_id),
            Session.user_id == current_user.id,
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    session.is_archived = True
    await db.commit()


@router.post("/sessions/{session_id}/send", response_model=SendResponse)
async def send_message(
    session_id: str,
    body: SendMessageRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Send a message and receive Ram's response.
    Full flow:
    1. Validate nonce (anti-replay)
    2. Rate limit check
    3. Load encrypted history → decrypt for LLM context
    4. Generate LLM response (plaintext in memory)
    5. Encrypt both messages → store in DB
    6. Return decrypted response to client (TLS protects transit)
    """
    # 1. Validate session belongs to user
    sess_result = await db.execute(
        select(Session).where(
            Session.id       == uuid.UUID(session_id),
            Session.user_id  == current_user.id,
            Session.is_archived == False,
        )
    )
    session = sess_result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # 2. Anti-replay nonce check
    await _check_nonce(body.nonce, str(current_user.id), db)

    # 3. Rate limit
    await rate_limit_user(
        str(current_user.id),
        "chat_send",
        limit=30,
        window=60,
    )

    # 4. Validate input
    content = body.content.strip()
    if not content:
        raise HTTPException(status_code=400, detail="Message cannot be empty")
    if len(content) > 8192:
        raise HTTPException(status_code=400, detail="Message too long (max 8192 chars)")

    # 5. Load history for LLM context
    history = await _load_history(session_id, current_user, db)
    history = llm.trim_history_to_context(history)

    # 6. Generate response (plaintext, in memory)
    display_name = current_user.display_name or current_user.username
    response_text = await llm.generate(
        user_message=content,
        history=history,
        display_name=display_name,
    )

    # 7. Encrypt and store both messages
    user_key = await get_user_key(str(current_user.id), current_user.key_envelope)

    user_msg = await _store_message(
        uuid.UUID(session_id), current_user, "user", content, db, user_key
    )
    asst_msg = await _store_message(
        uuid.UUID(session_id), current_user, "assistant", response_text, db, user_key
    )

    # 8. Update session timestamp
    session.updated_at = __import__("datetime").datetime.utcnow()

    await db.commit()
    await db.refresh(user_msg)
    await db.refresh(asst_msg)

    return SendResponse(
        session_id=session_id,
        user_message=MessageResponse(
            message_id=str(user_msg.id),
            role="user",
            content=content,
            created_at=user_msg.created_at.isoformat(),
        ),
        assistant_message=MessageResponse(
            message_id=str(asst_msg.id),
            role="assistant",
            content=response_text,
            created_at=asst_msg.created_at.isoformat(),
        ),
    )


@router.get("/sessions/{session_id}/history", response_model=list[MessageResponse])
async def get_history(
    session_id: str,
    limit: int = 50,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Load and return decrypted chat history for a session."""
    # Verify session ownership
    sess_result = await db.execute(
        select(Session).where(
            Session.id      == uuid.UUID(session_id),
            Session.user_id == current_user.id,
        )
    )
    if not sess_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Session not found")

    result = await db.execute(
        select(Message)
        .where(
            Message.session_id == uuid.UUID(session_id),
            Message.user_id    == current_user.id,
        )
        .order_by(Message.created_at.asc())
        .limit(min(limit, 100))
    )
    messages = result.scalars().all()

    user_key = await get_user_key(str(current_user.id), current_user.key_envelope)

    out = []
    for msg in messages:
        try:
            content = RamCrypto.decrypt(msg.content_enc, user_key)
            out.append(MessageResponse(
                message_id=str(msg.id),
                role=msg.role,
                content=content,
                created_at=msg.created_at.isoformat(),
            ))
        except Exception:
            continue
    return out


@router.get("/sessions/{session_id}/stream")
async def stream_message(
    session_id: str,
    message: str,
    nonce: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    SSE Streaming endpoint.
    Usage: GET /chat/sessions/{id}/stream?message=hello&nonce=<uuid4>
    Returns Server-Sent Events with content chunks.
    """
    # Validate session
    sess_result = await db.execute(
        select(Session).where(
            Session.id      == uuid.UUID(session_id),
            Session.user_id == current_user.id,
            Session.is_archived == False,
        )
    )
    session = sess_result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    await _check_nonce(nonce, str(current_user.id), db)
    await rate_limit_user(str(current_user.id), "chat_stream", limit=30, window=60)

    history = await _load_history(session_id, current_user, db)
    history = llm.trim_history_to_context(history)
    display_name = current_user.display_name or current_user.username

    async def event_stream() -> AsyncGenerator[str, None]:
        full_response = []

        async for chunk in llm.generate_stream(
            user_message=message,
            history=history,
            display_name=display_name,
        ):
            full_response.append(chunk)
            data = json.dumps({"type": "chunk", "content": chunk})
            yield f"data: {data}\n\n"

        # Store complete exchange in DB after streaming done
        complete_response = "".join(full_response)
        user_key = await get_user_key(str(current_user.id), current_user.key_envelope)
        async with db.begin():
            await _store_message(
                uuid.UUID(session_id), current_user, "user", message, db, user_key
            )
            await _store_message(
                uuid.UUID(session_id), current_user, "assistant", complete_response, db, user_key
            )

        yield f"data: {json.dumps({'type': 'done'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":    "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
