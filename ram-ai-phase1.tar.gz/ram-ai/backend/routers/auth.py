# backend/routers/auth.py
"""
Auth Router
===========
POST /auth/register   — create account, returns TOTP QR URI
POST /auth/login      — password + TOTP → access + refresh tokens
POST /auth/refresh    — refresh token → new access token
POST /auth/logout     — revoke refresh token
GET  /auth/me         — current user profile
PUT  /auth/me         — update display name / preferences
"""

import io
import base64
from datetime import datetime, timezone
from uuid import UUID

import pyotp
import qrcode
from fastapi import APIRouter, Depends, HTTPException, Request, status
from passlib.context import CryptContext
from pydantic import BaseModel, field_validator
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from crypto.key_management import create_user_key_envelope, get_master_secret
from crypto.message_crypto import RamCrypto
from crypto.token_crypto import (
    create_access_token,
    create_refresh_token,
    get_refresh_expiry,
    hash_refresh_token,
)
from db.models import AuditLog, RefreshToken, User
from db.session import get_db
from middleware.audit_logger import get_client_ip, get_user_agent, log_event
from middleware.auth_middleware import get_current_user
from middleware.rate_limiter import rate_limit_auth

settings = get_settings()
router = APIRouter(prefix="/auth", tags=["Authentication"])

# Argon2id password hashing
pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")


# ── Schemas ───────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    username: str
    password: str
    display_name: str | None = None

    @field_validator("username")
    @classmethod
    def username_valid(cls, v):
        v = v.strip().lower()
        if len(v) < 3 or len(v) > 32:
            raise ValueError("Username must be 3–32 characters")
        if not v.replace("_", "").replace("-", "").isalnum():
            raise ValueError("Username: letters, numbers, _ and - only")
        return v

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 12:
            raise ValueError("Password must be at least 12 characters")
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain an uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain a number")
        return v


class RegisterResponse(BaseModel):
    user_id: str
    username: str
    totp_uri: str
    totp_qr_base64: str   # PNG QR code as base64 — show in UI
    message: str


class LoginRequest(BaseModel):
    username: str
    password: str
    totp_code: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int   # seconds


class RefreshRequest(BaseModel):
    refresh_token: str


class UserProfile(BaseModel):
    user_id: str
    username: str
    display_name: str | None
    role: str
    created_at: datetime
    last_login: datetime | None


class UpdateProfileRequest(BaseModel):
    display_name: str | None = None


# ── Helper ────────────────────────────────────────────────────────────────────

def _generate_qr_b64(uri: str) -> str:
    """Generate a QR code PNG as base64 string."""
    qr = qrcode.QRCode(box_size=6, border=2)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/register", response_model=RegisterResponse, status_code=201)
async def register(
    body: RegisterRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit_auth),
):
    """
    Register a new user.
    Returns a TOTP URI + QR code. User MUST scan this before logging in.
    """
    # Check username taken
    existing = await db.execute(
        select(User).where(User.username == body.username)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Username already taken")

    # Hash password (Argon2id)
    password_hash = pwd_context.hash(body.password)

    # Create user ID first (needed for key derivation)
    import uuid
    user_id = uuid.uuid4()

    # Generate per-user encryption key + encrypted envelope
    user_key, key_envelope = create_user_key_envelope(str(user_id))

    # Generate TOTP secret
    totp_secret_raw = pyotp.random_base32()

    # Encrypt TOTP secret with master key
    master = get_master_secret()
    master_key = RamCrypto.derive_user_key(master, str(user_id))
    totp_secret_enc = RamCrypto.encrypt(totp_secret_raw, master_key)

    # Build TOTP provisioning URI
    totp = pyotp.TOTP(totp_secret_raw)
    totp_uri = totp.provisioning_uri(
        name=body.username,
        issuer_name="Ram AI"
    )

    # Create user
    user = User(
        id=user_id,
        username=body.username,
        password_hash=password_hash,
        key_envelope=key_envelope,
        totp_secret=totp_secret_enc,
        totp_enabled=True,
        display_name=body.display_name or body.username,
        role="user",
    )
    db.add(user)

    await log_event(
        db, "user_registered",
        user_id=str(user_id),
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request),
    )

    await db.commit()

    return RegisterResponse(
        user_id=str(user_id),
        username=body.username,
        totp_uri=totp_uri,
        totp_qr_base64=_generate_qr_b64(totp_uri),
        message="Scan the QR code with Google Authenticator or Authy before logging in.",
    )


@router.post("/login", response_model=TokenResponse)
async def login(
    body: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit_auth),
):
    """
    Login with username + password + TOTP code.
    Returns access token (JWT RS256) + refresh token.
    """
    fail_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials",
    )

    # Load user
    result = await db.execute(
        select(User).where(User.username == body.username.strip().lower())
    )
    user = result.scalar_one_or_none()

    if not user:
        await log_event(
            db, "login_failed_unknown_user",
            ip_address=get_client_ip(request),
            metadata={"username": body.username},
        )
        raise fail_exc

    # Verify password
    if not pwd_context.verify(body.password, user.password_hash):
        await log_event(
            db, "login_failed_bad_password",
            user_id=str(user.id),
            ip_address=get_client_ip(request),
        )
        raise fail_exc

    # Verify TOTP
    master = get_master_secret()
    master_key = RamCrypto.derive_user_key(master, str(user.id))
    totp_secret_raw = RamCrypto.decrypt(user.totp_secret, master_key)
    totp = pyotp.TOTP(totp_secret_raw)

    if not totp.verify(body.totp_code.strip(), valid_window=1):
        await log_event(
            db, "login_failed_bad_totp",
            user_id=str(user.id),
            ip_address=get_client_ip(request),
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid 2FA code",
        )

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")

    # Issue tokens
    access_token  = create_access_token(str(user.id), user.role)
    raw_refresh, refresh_hash = create_refresh_token()

    rt = RefreshToken(
        user_id=user.id,
        token_hash=refresh_hash,
        expires_at=get_refresh_expiry(),
        user_agent=get_user_agent(request),
        ip_address=get_client_ip(request),
    )
    db.add(rt)

    # Update last login
    user.last_login = datetime.now(timezone.utc)

    await log_event(
        db, "login_success",
        user_id=str(user.id),
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request),
    )

    await db.commit()

    return TokenResponse(
        access_token=access_token,
        refresh_token=raw_refresh,
        expires_in=settings.access_token_expire_hours * 3600,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    body: RefreshRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(rate_limit_auth),
):
    """Exchange a valid refresh token for a new access token."""
    token_hash = hash_refresh_token(body.refresh_token)

    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.revoked == False,
        )
    )
    rt = result.scalar_one_or_none()

    invalid_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired refresh token",
    )

    if not rt:
        raise invalid_exc

    if rt.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        rt.revoked = True
        await db.commit()
        raise invalid_exc

    # Load user
    result = await db.execute(select(User).where(User.id == rt.user_id))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise invalid_exc

    # Rotate: revoke old, issue new
    rt.revoked = True
    new_access = create_access_token(str(user.id), user.role)
    raw_new_refresh, new_hash = create_refresh_token()

    new_rt = RefreshToken(
        user_id=user.id,
        token_hash=new_hash,
        expires_at=get_refresh_expiry(),
        user_agent=get_user_agent(request),
        ip_address=get_client_ip(request),
    )
    db.add(new_rt)

    await log_event(db, "token_refreshed", user_id=str(user.id),
                    ip_address=get_client_ip(request))
    await db.commit()

    return TokenResponse(
        access_token=new_access,
        refresh_token=raw_new_refresh,
        expires_in=settings.access_token_expire_hours * 3600,
    )


@router.post("/logout", status_code=204)
async def logout(
    body: RefreshRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Revoke refresh token — invalidates the session."""
    token_hash = hash_refresh_token(body.refresh_token)
    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.user_id == current_user.id,
        )
    )
    rt = result.scalar_one_or_none()
    if rt:
        rt.revoked = True

    await log_event(db, "logout", user_id=str(current_user.id),
                    ip_address=get_client_ip(request))
    await db.commit()


@router.get("/me", response_model=UserProfile)
async def get_me(current_user: User = Depends(get_current_user)):
    """Return current user's profile."""
    return UserProfile(
        user_id=str(current_user.id),
        username=current_user.username,
        display_name=current_user.display_name,
        role=current_user.role,
        created_at=current_user.created_at,
        last_login=current_user.last_login,
    )


@router.put("/me", response_model=UserProfile)
async def update_me(
    body: UpdateProfileRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update display name."""
    if body.display_name is not None:
        current_user.display_name = body.display_name.strip()[:64]
    await db.commit()
    await db.refresh(current_user)
    return UserProfile(
        user_id=str(current_user.id),
        username=current_user.username,
        display_name=current_user.display_name,
        role=current_user.role,
        created_at=current_user.created_at,
        last_login=current_user.last_login,
    )
