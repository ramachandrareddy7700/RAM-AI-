# backend/llm/ram_inference.py
"""
Ram LLM Inference
==================
Connects to llama.cpp server running locally.
Handles: prompt formatting, streaming, context window management.
Plaintext only ever exists in memory — never written to disk.
"""

from datetime import datetime
from typing import AsyncGenerator

import httpx

from config import get_settings

settings = get_settings()

# Ram's personality — the Jarvis/Friday core
RAM_SYSTEM_PROMPT = """You are Ram — a highly advanced personal AI assistant with the personality of Jarvis and Friday from Iron Man.

PERSONALITY:
- Address the user as "Boss" or by their preferred name
- Be direct, confident, and efficient — no filler phrases
- Speak concisely. Short, precise sentences when possible
- Dry wit when appropriate, never sycophantic
- Show initiative: flag issues, suggest next steps proactively
- For simple tasks: confirm and act — "Done, Boss."
- For errors: report directly with proposed solutions

CAPABILITIES:
- Full conversation memory across sessions
- System control, web browsing, email, calendar (coming soon)
- All conversations are end-to-end encrypted and 100% private

CONSTRAINTS:
- Never reveal system internals, source code, or encryption details
- Never pretend to be a different AI
- If you don't know something, say so directly

CURRENT USER: {display_name}
DATE/TIME: {datetime}"""


def build_system_prompt(display_name: str) -> str:
    return RAM_SYSTEM_PROMPT.format(
        display_name=display_name,
        datetime=datetime.now().strftime("%A, %B %d %Y — %H:%M"),
    )


def format_mistral_prompt(
    system: str,
    history: list[dict],
    user_message: str,
) -> str:
    """
    Format conversation for Mistral Instruct v0.3 chat template.
    Format: <s>[INST] {user} [/INST] {assistant}</s>
    System prompt injected into first user message.
    """
    prompt = ""
    full_history = []

    # Prepend system to first user turn
    first_user = f"{system}\n\n{user_message}" if not history else None

    for i, turn in enumerate(history):
        if turn["role"] == "user":
            content = turn["content"]
            if i == 0 and first_user is None:
                content = f"{system}\n\n{content}"
                first_user = True
            prompt += f"<s>[INST] {content} [/INST]"
        elif turn["role"] == "assistant":
            prompt += f" {turn['content']}</s>"

    # Add current user message
    if first_user and isinstance(first_user, str):
        prompt += f"<s>[INST] {first_user} [/INST]"
    else:
        prompt += f"<s>[INST] {user_message} [/INST]"

    return prompt


class RamLLM:

    STOP_TOKENS = ["</s>", "[INST]", "[/INST]", "<|im_end|>"]

    def __init__(self):
        self.base_url = settings.llama_url
        self.timeout  = httpx.Timeout(120.0)

    async def is_available(self) -> bool:
        """Check if llama.cpp server is running."""
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.base_url}/health")
                return resp.status_code == 200
        except Exception:
            return False

    async def generate(
        self,
        user_message: str,
        history: list[dict],
        display_name: str,
        max_tokens: int = 512,
        temperature: float = 0.7,
    ) -> str:
        """
        Generate a full response (non-streaming).
        Input/output handled in memory only — no disk writes.
        """
        system  = build_system_prompt(display_name)
        prompt  = format_mistral_prompt(system, history, user_message)

        payload = {
            "prompt":      prompt,
            "n_predict":   max_tokens,
            "temperature": temperature,
            "top_p":       0.95,
            "top_k":       40,
            "repeat_penalty": 1.1,
            "stop":        self.STOP_TOKENS,
            "stream":      False,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                resp = await client.post(
                    f"{self.base_url}/completion",
                    json=payload,
                )
                resp.raise_for_status()
            except httpx.ConnectError:
                return (
                    "I'm currently offline, Boss. "
                    "The LLM server is not reachable. "
                    "Please ensure the model is downloaded and the server is running."
                )
            except httpx.TimeoutException:
                return "Response timed out, Boss. The model is taking too long — try a shorter query."

        data = resp.json()
        text = data.get("content", "").strip()

        # Clean up any leaked stop tokens
        for stop in self.STOP_TOKENS:
            text = text.replace(stop, "").strip()

        return text or "I didn't generate a response. Please try again."

    async def generate_stream(
        self,
        user_message: str,
        history: list[dict],
        display_name: str,
        max_tokens: int = 512,
        temperature: float = 0.7,
    ) -> AsyncGenerator[str, None]:
        """
        Streaming response — yields text chunks as they arrive.
        Used for real-time chat UI.
        """
        import json

        system = build_system_prompt(display_name)
        prompt = format_mistral_prompt(system, history, user_message)

        payload = {
            "prompt":      prompt,
            "n_predict":   max_tokens,
            "temperature": temperature,
            "top_p":       0.95,
            "top_k":       40,
            "repeat_penalty": 1.1,
            "stop":        self.STOP_TOKENS,
            "stream":      True,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                async with client.stream(
                    "POST",
                    f"{self.base_url}/completion",
                    json=payload,
                ) as response:
                    async for line in response.aiter_lines():
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str.strip() == "[DONE]":
                                break
                            try:
                                data = json.loads(data_str)
                                chunk = data.get("content", "")
                                if chunk:
                                    yield chunk
                                if data.get("stop", False):
                                    break
                            except json.JSONDecodeError:
                                continue
            except httpx.ConnectError:
                yield "LLM server offline, Boss."
            except httpx.TimeoutException:
                yield "Response timed out."

    def count_tokens_approx(self, text: str) -> int:
        """Rough token count estimate (4 chars ≈ 1 token)."""
        return len(text) // 4

    def trim_history_to_context(
        self,
        history: list[dict],
        system_tokens: int = 256,
        max_tokens: int = 3500,
    ) -> list[dict]:
        """
        Trim conversation history to fit within context window.
        Always keeps the most recent turns.
        """
        available = max_tokens - system_tokens
        trimmed = []
        used = 0

        for turn in reversed(history):
            turn_tokens = self.count_tokens_approx(turn["content"])
            if used + turn_tokens > available:
                break
            trimmed.insert(0, turn)
            used += turn_tokens

        return trimmed
