# backend/db/models.py
import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Boolean, DateTime,
    Integer, Text, ForeignKey, func
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from db.session import Base


class User(Base):
    __tablename__ = "users"

    id             = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username       = Column(String, unique=True, nullable=False, index=True)
    email          = Column(String, unique=True, nullable=True)
    password_hash  = Column(Text, nullable=False)
    key_envelope   = Column(Text, nullable=False)   # encrypted per-user key
    totp_secret    = Column(Text, nullable=False)   # encrypted TOTP secret
    totp_enabled   = Column(Boolean, default=True)
    role           = Column(String, default="user")
    is_active      = Column(Boolean, default=True)
    display_name   = Column(String, nullable=True)
    preferences_enc = Column(Text, nullable=True)
    created_at     = Column(DateTime(timezone=True), server_default=func.now())
    last_login     = Column(DateTime(timezone=True), nullable=True)

    sessions       = relationship("Session", back_populates="user", cascade="all, delete")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete")
    memory         = relationship("UserMemory", back_populates="user", cascade="all, delete")


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id     = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    token_hash  = Column(Text, unique=True, nullable=False)
    expires_at  = Column(DateTime(timezone=True), nullable=False)
    revoked     = Column(Boolean, default=False)
    user_agent  = Column(Text, nullable=True)
    ip_address  = Column(Text, nullable=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="refresh_tokens")


class Session(Base):
    __tablename__ = "sessions"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id     = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    title_enc   = Column(Text, nullable=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
    updated_at  = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    is_archived = Column(Boolean, default=False)

    user     = relationship("User", back_populates="sessions")
    messages = relationship("Message", back_populates="session", cascade="all, delete")


class Message(Base):
    __tablename__ = "messages"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id  = Column(UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"))
    user_id     = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    role        = Column(String, nullable=False)   # 'user' | 'assistant'
    content_enc = Column(Text, nullable=False)     # encrypted
    token_count = Column(Integer, nullable=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    session = relationship("Session", back_populates="messages")


class UserMemory(Base):
    __tablename__ = "user_memory"

    id              = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id         = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    fact_key        = Column(Text, nullable=False)
    fact_value_enc  = Column(Text, nullable=False)
    created_at      = Column(DateTime(timezone=True), server_default=func.now())
    updated_at      = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user = relationship("User", back_populates="memory")


class UsedNonce(Base):
    __tablename__ = "used_nonces"

    nonce   = Column(Text, primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    used_at = Column(DateTime(timezone=True), server_default=func.now())


class AuditLog(Base):
    __tablename__ = "audit_log"

    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    event      = Column(Text, nullable=False)
    ip_address = Column(Text, nullable=True)
    user_agent = Column(Text, nullable=True)
    metadata   = Column(JSONB, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Reminder(Base):
    __tablename__ = "reminders"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id     = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    message_enc = Column(Text, nullable=False)
    fire_at     = Column(DateTime(timezone=True), nullable=False)
    fired       = Column(Boolean, default=False)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())
