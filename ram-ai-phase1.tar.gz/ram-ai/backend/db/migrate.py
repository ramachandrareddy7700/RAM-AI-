# backend/db/migrate.py
"""Run on first boot to apply schema."""
import asyncio
from pathlib import Path
import asyncpg
from config import get_settings

settings = get_settings()


async def run_migrations():
    sql_file = Path(__file__).parent / "init.sql"
    sql = sql_file.read_text()

    conn = await asyncpg.connect(settings.sync_database_url.replace(
        "postgresql://", "postgresql://"
    ).replace("+asyncpg", ""))

    try:
        await conn.execute(sql)
        print("[RAM] ✓ Database schema applied successfully")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(run_migrations())
