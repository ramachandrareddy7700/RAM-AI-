-- ─── RAM AI — Database Schema ─────────────────────────────────────────────────
-- PostgreSQL 16 + pgvector + pgcrypto
-- All sensitive columns encrypted at application layer before INSERT

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;

-- ── Users ─────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id                  UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    username            TEXT        UNIQUE NOT NULL,
    email               TEXT        UNIQUE,
    -- Argon2id hash (never plain password)
    password_hash       TEXT        NOT NULL,
    -- Per-user XSalsa20 key, encrypted with master key (base64)
    key_envelope        TEXT        NOT NULL,
    -- TOTP secret encrypted with master key
    totp_secret         TEXT        NOT NULL,
    totp_enabled        BOOLEAN     DEFAULT TRUE,
    -- User role: 'user' | 'admin'
    role                TEXT        NOT NULL DEFAULT 'user'
                                    CHECK (role IN ('user', 'admin')),
    is_active           BOOLEAN     DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    last_login          TIMESTAMPTZ,
    -- Encrypted user preferences JSON blob
    preferences_enc     TEXT,
    -- Display name (not sensitive)
    display_name        TEXT
);

-- ── Refresh Tokens ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  TEXT        NOT NULL UNIQUE, -- SHA-256 of the token
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    revoked     BOOLEAN     DEFAULT FALSE,
    user_agent  TEXT,
    ip_address  TEXT
);

-- ── Chat Sessions ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    -- Encrypted session title
    title_enc   TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    is_archived BOOLEAN     DEFAULT FALSE
);

-- ── Messages ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
    id                  UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id          UUID        NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    user_id             UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role                TEXT        NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    -- AES-256-GCM / XSalsa20 encrypted content (base64)
    content_enc         TEXT        NOT NULL,
    -- Token count for context window management
    token_count         INTEGER,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── User Memory (Long-Term Facts) ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_memory (
    id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    -- Fact key (not sensitive, used for dedup)
    fact_key        TEXT        NOT NULL,
    -- Encrypted fact value
    fact_value_enc  TEXT        NOT NULL,
    -- Vector embedding for semantic search (384 dims = MiniLM-L6)
    embedding       vector(384),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, fact_key)
);

-- ── Nonces (Anti-Replay) ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS used_nonces (
    nonce       TEXT        PRIMARY KEY,
    user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    used_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── Reminders ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reminders (
    id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message_enc TEXT        NOT NULL,
    fire_at     TIMESTAMPTZ NOT NULL,
    fired       BOOLEAN     DEFAULT FALSE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Audit Log ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID        REFERENCES users(id) ON DELETE SET NULL,
    event       TEXT        NOT NULL,
    ip_address  TEXT,
    user_agent  TEXT,
    metadata    JSONB,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Indexes ───────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_messages_session    ON messages(session_id);
CREATE INDEX IF NOT EXISTS idx_messages_user       ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created    ON messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_user       ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_updated    ON sessions(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_memory_user         ON user_memory(user_id);
CREATE INDEX IF NOT EXISTS idx_nonces_used_at      ON used_nonces(used_at);
CREATE INDEX IF NOT EXISTS idx_refresh_user        ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_user          ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_event         ON audit_log(event);
CREATE INDEX IF NOT EXISTS idx_reminders_fire      ON reminders(fire_at) WHERE NOT fired;

-- HNSW index for fast semantic memory search
CREATE INDEX IF NOT EXISTS idx_memory_embedding
    ON user_memory USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- ── Auto-update updated_at ────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_sessions_updated
    BEFORE UPDATE ON sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE OR REPLACE TRIGGER trg_memory_updated
    BEFORE UPDATE ON user_memory
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── Nonce cleanup function (call via cron/background task) ────────────────────
CREATE OR REPLACE FUNCTION cleanup_old_nonces()
RETURNS void AS $$
BEGIN
    DELETE FROM used_nonces WHERE used_at < NOW() - INTERVAL '1 hour';
END;
$$ LANGUAGE plpgsql;
