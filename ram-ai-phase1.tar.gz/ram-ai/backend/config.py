# backend/config.py
from pydantic_settings import BaseSettings
from functools import lru_cache
from pathlib import Path


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────────────────────
    app_name: str = "Ram AI"
    environment: str = "development"
    debug: bool = False

    # ── Database ─────────────────────────────────────────────────────────────
    db_user: str = "ram"
    db_password: str
    db_name: str = "ram"
    db_host: str = "postgres"
    db_port: int = 5432

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @property
    def sync_database_url(self) -> str:
        return (
            f"postgresql://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    # ── Redis ─────────────────────────────────────────────────────────────────
    redis_password: str
    redis_host: str = "redis"
    redis_port: int = 6379

    @property
    def redis_url(self) -> str:
        return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/0"

    # ── JWT ───────────────────────────────────────────────────────────────────
    jwt_algorithm: str = "RS256"
    access_token_expire_hours: int = 8
    refresh_token_expire_days: int = 30

    @property
    def jwt_private_key(self) -> str:
        key_path = Path("/run/secrets/jwt_private_key")
        if not key_path.exists():
            key_path = Path("secrets/jwt_private_key.pem")
        return key_path.read_text()

    @property
    def jwt_public_key(self) -> str:
        key_path = Path("secrets/jwt_public_key.pem")
        return key_path.read_text()

    # ── Master Encryption Key ─────────────────────────────────────────────────
    @property
    def master_secret(self) -> bytes:
        key_path = Path("/run/secrets/master_secret")
        if not key_path.exists():
            key_path = Path("secrets/master_secret.bin")
        return key_path.read_bytes()

    # ── LLM ───────────────────────────────────────────────────────────────────
    model_path: str = "/models/mistral-7b-instruct-v0.3.Q4_K_M.gguf"
    llama_host: str = "127.0.0.1"
    llama_port: int = 8181
    llm_threads: int = 8
    llm_ctx: int = 4096

    @property
    def llama_url(self) -> str:
        return f"http://{self.llama_host}:{self.llama_port}"

    # ── Rate Limiting ─────────────────────────────────────────────────────────
    rate_limit_per_minute: int = 30

    # ── CORS ──────────────────────────────────────────────────────────────────
    allowed_origins: list[str] = ["http://localhost:3000", "https://localhost"]

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
