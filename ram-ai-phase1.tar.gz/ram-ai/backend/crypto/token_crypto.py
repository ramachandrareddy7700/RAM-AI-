# backend/crypto/token_crypto.py
"""
JWT Utilities — RS256 (asymmetric)
===================================
Access token  : short-lived (8h), signed with RSA private key
Refresh token : long-lived (30d), hashed and stored in DB
"""

import hashlib
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from jose import JWTError, jwt

from config import get_settings

settings = get_settings()


# ── Access Token ──────────────────────────────────────────────────────────────

def create_access_token(user_id: str, role: str) -> str:
    """Create a signed RS256 JWT access token."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub":  user_id,
        "role": role,
        "iat":  now,
        "exp":  now + timedelta(hours=settings.access_token_expire_hours),
        "jti":  os.urandom(16).hex(),   # unique token ID
        "type": "access",
    }
    return jwt.encode(
        payload,
        settings.jwt_private_key,
        algorithm=settings.jwt_algorithm,
    )


def verify_access_token(token: str) -> dict:
    """
    Verify and decode an access token.
    Raises JWTError on invalid/expired token.
    """
    payload = jwt.decode(
        token,
        settings.jwt_public_key,
        algorithms=[settings.jwt_algorithm],
    )
    if payload.get("type") != "access":
        raise JWTError("Not an access token")
    return payload


# ── Refresh Token ─────────────────────────────────────────────────────────────

def create_refresh_token() -> tuple[str, str]:
    """
    Generate a refresh token.
    Returns: (raw_token_for_client, hash_for_db)
    The raw token is sent to the client — never stored in DB.
    Only the SHA-256 hash is stored.
    """
    raw = secrets.token_urlsafe(64)
    hashed = hashlib.sha256(raw.encode()).hexdigest()
    return raw, hashed


def hash_refresh_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def get_refresh_expiry() -> datetime:
    return datetime.now(timezone.utc) + timedelta(
        days=settings.refresh_token_expire_days
    )
