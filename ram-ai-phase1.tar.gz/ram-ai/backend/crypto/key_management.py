# backend/crypto/key_management.py
"""
Key Management
==============
Master secret  → loaded once from file/Docker secret, cached in memory
Per-user keys  → derived on demand from master + user_id, cached in Redis
Key envelopes  → encrypted per-user keys stored in PostgreSQL
"""

import asyncio
from functools import lru_cache
from typing import Optional

import redis.asyncio as aioredis

from config import get_settings
from crypto.message_crypto import RamCrypto

settings = get_settings()

# In-memory key cache (process-level)
_key_cache: dict[str, bytes] = {}
_cache_lock = asyncio.Lock()


@lru_cache(maxsize=1)
def get_master_secret() -> bytes:
    """Load master secret from file. Cached after first load."""
    secret = settings.master_secret
    if len(secret) != 32:
        raise ValueError(
            f"Master secret must be 32 bytes, got {len(secret)}"
        )
    return secret


async def get_user_key(
    user_id: str,
    key_envelope: str,
    redis_client: Optional[aioredis.Redis] = None,
) -> bytes:
    """
    Retrieve or derive a user's encryption key.
    Order: process cache → Redis cache → derive from master + unwrap envelope
    """
    cache_key = f"ram:userkey:{user_id}"

    # 1. Process-level cache (fastest)
    if cache_key in _key_cache:
        return _key_cache[cache_key]

    # 2. Redis cache (survives process restart)
    if redis_client:
        cached = await redis_client.get(cache_key)
        if cached:
            key = bytes.fromhex(cached.decode())
            _key_cache[cache_key] = key
            return key

    # 3. Derive from master secret + key envelope
    async with _cache_lock:
        # Double-check after acquiring lock
        if cache_key in _key_cache:
            return _key_cache[cache_key]

        master = get_master_secret()
        user_key = RamCrypto.unwrap_key(key_envelope, master, user_id)

        # Cache in memory
        _key_cache[cache_key] = user_key

        # Cache in Redis (TTL: 8 hours = one session)
        if redis_client:
            await redis_client.setex(
                cache_key,
                8 * 3600,
                user_key.hex()
            )

        return user_key


def invalidate_user_key(user_id: str):
    """Remove user's key from process cache (e.g. on password change)."""
    cache_key = f"ram:userkey:{user_id}"
    _key_cache.pop(cache_key, None)


def create_user_key_envelope(user_id: str) -> tuple[bytes, str]:
    """
    Create a brand-new key + envelope for a new user.
    Returns: (raw_key, encrypted_envelope_for_db)
    """
    master = get_master_secret()
    user_key = RamCrypto.generate_key()
    envelope = RamCrypto.wrap_key(user_key, master, user_id)
    return user_key, envelope
