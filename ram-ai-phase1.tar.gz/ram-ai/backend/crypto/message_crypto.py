# backend/crypto/message_crypto.py
"""
RAM AI — Encryption Layer
=========================
Algorithm : XSalsa20-Poly1305 (libsodium SecretBox via PyNaCl)
Key size  : 256-bit (32 bytes)
Nonce     : 192-bit random per message (included in ciphertext)
Auth tag  : Poly1305 (16 bytes, built into SecretBox)

Every message stored in the DB goes through this layer.
The LLM sees only plaintext in memory — never on disk.
"""

import base64
import hashlib
import hmac
import os

import nacl.secret
import nacl.utils
import nacl.pwhash
import nacl.encoding


class RamCrypto:

    # ── Core encrypt / decrypt ────────────────────────────────────────────────

    @staticmethod
    def encrypt(plaintext: str, key: bytes) -> str:
        """
        Encrypt a string. Returns base64-encoded ciphertext
        (nonce is prepended automatically by SecretBox).
        """
        box = nacl.secret.SecretBox(key)
        encrypted = box.encrypt(plaintext.encode("utf-8"))
        return base64.b64encode(encrypted).decode("utf-8")

    @staticmethod
    def decrypt(ciphertext_b64: str, key: bytes) -> str:
        """
        Decrypt a base64-encoded ciphertext produced by encrypt().
        Raises nacl.exceptions.CryptoError on tampering.
        """
        box = nacl.secret.SecretBox(key)
        raw = base64.b64decode(ciphertext_b64)
        decrypted = box.decrypt(raw)
        return decrypted.decode("utf-8")

    # ── Key generation ────────────────────────────────────────────────────────

    @staticmethod
    def generate_key() -> bytes:
        """Generate a random 256-bit key."""
        return nacl.utils.random(nacl.secret.SecretBox.KEY_SIZE)

    # ── Per-user key derivation ───────────────────────────────────────────────

    @staticmethod
    def derive_user_key(master_secret: bytes, user_id: str) -> bytes:
        """
        Derive a deterministic 256-bit key for a specific user
        using HMAC-SHA256. Different user_id → completely different key.
        """
        return hmac.new(
            master_secret,
            f"ram:user-storage-key:{user_id}".encode(),
            hashlib.sha256,
        ).digest()

    # ── Key envelope (wrap/unwrap) ────────────────────────────────────────────

    @staticmethod
    def wrap_key(user_key: bytes, master_secret: bytes, user_id: str) -> str:
        """
        Encrypt a user's box key using their master-derived key.
        Stored as 'key_envelope' in the DB.
        """
        wrapping_key = RamCrypto.derive_user_key(master_secret, user_id)
        return RamCrypto.encrypt(user_key.hex(), wrapping_key)

    @staticmethod
    def unwrap_key(key_envelope: str, master_secret: bytes, user_id: str) -> bytes:
        """Decrypt the user's key envelope to recover their box key."""
        wrapping_key = RamCrypto.derive_user_key(master_secret, user_id)
        key_hex = RamCrypto.decrypt(key_envelope, wrapping_key)
        return bytes.fromhex(key_hex)

    # ── Nonce generation (anti-replay) ────────────────────────────────────────

    @staticmethod
    def generate_nonce() -> str:
        """Generate a cryptographically random nonce (hex, 128-bit)."""
        return os.urandom(16).hex()
