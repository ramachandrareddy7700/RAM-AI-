# backend/main.py
"""
RAM AI — FastAPI Application Entry Point
=========================================
Boots the full server: DB, Redis, routers, middleware, health checks.
"""

import asyncio
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse

from config import get_settings
from db.session import engine, Base
from middleware.rate_limiter import set_redis_client
from routers import auth, chat

settings = get_settings()

# ── Redis client (global) ─────────────────────────────────────────────────────
redis_client: aioredis.Redis | None = None


# ── Lifespan (startup + shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global redis_client

    # Startup
    print("[Ram] Starting up...")

    # Connect to Redis
    try:
        redis_client = aioredis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True,
        )
        await redis_client.ping()
        set_redis_client(redis_client)
        print("[Ram] ✓ Redis connected")
    except Exception as e:
        print(f"[Ram] ⚠ Redis unavailable: {e} — rate limiting disabled")

    # Create DB tables (idempotent)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("[Ram] ✓ Database ready")

    # Background: nonce cleanup every 30 minutes
    asyncio.create_task(_cleanup_nonces())

    print("[Ram] ✓ All systems go. Ram is online.")
    yield

    # Shutdown
    if redis_client:
        await redis_client.close()
    await engine.dispose()
    print("[Ram] Shutdown complete.")


async def _cleanup_nonces():
    """Background task: remove expired nonces every 30 minutes."""
    from db.session import AsyncSessionLocal
    from sqlalchemy import text
    while True:
        await asyncio.sleep(1800)
        async with AsyncSessionLocal() as db:
            await db.execute(
                text("SELECT cleanup_old_nonces()")
            )
            await db.commit()


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Ram AI",
    description="Encrypted Personal AI Assistant",
    version="1.0.0",
    docs_url="/docs" if settings.environment == "development" else None,
    redoc_url=None,
    lifespan=lifespan,
)

# ── Middleware ─────────────────────────────────────────────────────────────────

# Security headers
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"]    = "nosniff"
    response.headers["X-Frame-Options"]           = "DENY"
    response.headers["X-XSS-Protection"]          = "1; mode=block"
    response.headers["Referrer-Policy"]           = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]        = "geolocation=(), microphone=(), camera=()"
    response.headers["Content-Security-Policy"]   = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline';"
    )
    return response

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-Nonce"],
    max_age=600,
)

# Trusted hosts (production only)
if settings.environment == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=[settings.domain, f"www.{settings.domain}"],
    )

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router)
app.include_router(chat.router)

# ── Health Check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
async def health():
    """Public health check — used by Docker and monitoring."""
    from llm.ram_inference import RamLLM
    llm = RamLLM()
    llm_ok = await llm.is_available()

    redis_ok = False
    if redis_client:
        try:
            await redis_client.ping()
            redis_ok = True
        except Exception:
            pass

    return {
        "status":  "online",
        "name":    "Ram AI",
        "version": "1.0.0",
        "services": {
            "database": "ok",       # if we're here, DB is up
            "redis":    "ok" if redis_ok else "degraded",
            "llm":      "ok" if llm_ok else "offline",
        },
    }


@app.get("/", tags=["System"])
async def root():
    return {"message": "Ram AI is online. Boss."}


# ── Global error handlers ─────────────────────────────────────────────────────
@app.exception_handler(404)
async def not_found(_request, _exc):
    return JSONResponse(status_code=404, content={"detail": "Not found"})


@app.exception_handler(500)
async def server_error(_request, exc):
    print(f"[Ram] Server error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error — check logs"},
    )
