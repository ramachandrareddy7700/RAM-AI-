# backend/middleware/audit_logger.py
"""
Audit Logger
=============
Records all security-relevant events to the audit_log table.
Events: login, logout, register, failed_login, token_refresh,
        message_sent, password_change, user_created, etc.
"""

from typing import Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from db.models import AuditLog


async def log_event(
    db: AsyncSession,
    event: str,
    user_id: Optional[str] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    metadata: Optional[dict] = None,
):
    """Write a security event to the audit log."""
    entry = AuditLog(
        user_id=UUID(user_id) if user_id else None,
        event=event,
        ip_address=ip_address,
        user_agent=user_agent,
        metadata=metadata or {},
    )
    db.add(entry)
    # Don't commit here — let the request lifecycle handle it


def get_client_ip(request) -> str:
    """Extract real IP, respecting X-Forwarded-For from Nginx."""
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def get_user_agent(request) -> str:
    return request.headers.get("User-Agent", "unknown")[:512]
