# backend/middleware/rate_limiter.py
"""
Rate Limiter — Sliding Window (Redis-backed)
=============================================
- Per-user AND per-IP limits
- Auth endpoints: stricter limits (brute-force protection)
- Chat endpoints: standard limits
"""

from datetime import datetime, timezone
from functools import wraps

import redis.asyncio as aioredis
from fastapi import HTTPException, Request, status

from config import get_settings

settings = get_settings()

# Redis client (initialized in main.py, injected here)
_redis: aioredis.Redis | None = None


def set_redis_client(client: aioredis.Redis):
    global _redis
    _redis = client


async def check_rate_limit(
    key: str,
    limit: int,
    window_seconds: int = 60,
) -> tuple[int, int]:
    """
    Sliding window rate limiter.
    Returns: (remaining_requests, retry_after_seconds)
    Raises HTTP 429 if limit exceeded.
    """
    if not _redis:
        return limit, 0  # Redis not ready → allow all (fail open)

    now = datetime.now(timezone.utc).timestamp()
    window_start = now - window_seconds

    pipe = _redis.pipeline()
    # Remove old entries outside the window
    pipe.zremrangebyscore(key, 0, window_start)
    # Add current request
    pipe.zadd(key, {str(now): now})
    # Count requests in window
    pipe.zcard(key)
    # Set TTL
    pipe.expire(key, window_seconds)
    results = await pipe.execute()

    count = results[2]
    remaining = max(0, limit - count)

    if count > limit:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded. Try again in {window_seconds}s.",
            headers={"Retry-After": str(window_seconds)},
        )

    return remaining, 0


async def rate_limit_ip(request: Request, limit: int = 60, window: int = 60):
    """Limit by IP address — for public endpoints."""
    ip = request.client.host if request.client else "unknown"
    key = f"ram:rl:ip:{ip}:{request.url.path}"
    await check_rate_limit(key, limit, window)


async def rate_limit_user(user_id: str, endpoint: str, limit: int = 30, window: int = 60):
    """Limit by authenticated user ID."""
    key = f"ram:rl:user:{user_id}:{endpoint}"
    await check_rate_limit(key, limit, window)


async def rate_limit_auth(request: Request):
    """
    Strict rate limit for auth endpoints.
    5 attempts per minute per IP — brute-force protection.
    """
    await rate_limit_ip(request, limit=5, window=60)
