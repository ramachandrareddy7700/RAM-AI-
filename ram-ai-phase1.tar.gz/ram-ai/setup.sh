#!/usr/bin/env bash
# ─── RAM AI — Phase 1 Setup Script ────────────────────────────────────────────
# Run once on a fresh Ubuntu 24.04 server: sudo bash setup.sh
# Does everything: installs deps, generates secrets, builds containers

set -euo pipefail
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${GREEN}[RAM]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

log "═══════════════════════════════════════════"
log "       RAM AI — Phase 1 Setup              "
log "═══════════════════════════════════════════"

# ── 1. Check OS ──────────────────────────────────────────────────────────────
[[ "$EUID" -eq 0 ]] || err "Please run as root: sudo bash setup.sh"
. /etc/os-release
[[ "$ID" == "ubuntu" ]] || warn "Not Ubuntu — proceed with caution."

# ── 2. Install system deps ───────────────────────────────────────────────────
log "Installing system dependencies..."
apt-get update -q
apt-get install -y -q \
    docker.io docker-compose-plugin \
    openssl curl wget git \
    build-essential cmake \
    python3 python3-pip python3-venv \
    nginx certbot python3-certbot-nginx \
    ufw fail2ban

# Enable Docker
systemctl enable docker --now
usermod -aG docker "${SUDO_USER:-$USER}" 2>/dev/null || true

# ── 3. Firewall ───────────────────────────────────────────────────────────────
log "Configuring firewall..."
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
log "Firewall configured: SSH + 80 + 443 only."

# ── 4. Generate secrets ───────────────────────────────────────────────────────
log "Generating cryptographic secrets..."
mkdir -p secrets

# Master encryption key (32 bytes = 256-bit)
if [[ ! -f secrets/master_secret.bin ]]; then
    python3 -c "import os; open('secrets/master_secret.bin','wb').write(os.urandom(32))"
    log "  ✓ Master secret generated"
fi

# JWT RS256 key pair (4096-bit)
if [[ ! -f secrets/jwt_private_key.pem ]]; then
    openssl genrsa -out secrets/jwt_private_key.pem 4096 2>/dev/null
    openssl rsa -in secrets/jwt_private_key.pem \
        -pubout -out secrets/jwt_public_key.pem 2>/dev/null
    log "  ✓ JWT RS256 key pair generated"
fi

# Set strict permissions on secrets
chmod 600 secrets/master_secret.bin
chmod 600 secrets/jwt_private_key.pem
chmod 644 secrets/jwt_public_key.pem
log "  ✓ Secret permissions locked"

# ── 5. Copy .env ──────────────────────────────────────────────────────────────
if [[ ! -f .env ]]; then
    cp .env.example .env
    # Generate random passwords
    DB_PASS=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
    REDIS_PASS=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
    sed -i "s/change_this_strong_password_123/$DB_PASS/" .env
    sed -i "s/change_this_redis_password_456/$REDIS_PASS/" .env
    log "  ✓ .env created with random passwords"
    warn "  → Passwords saved to .env — back this up securely!"
fi

# ── 6. Create models directory ────────────────────────────────────────────────
mkdir -p models
log "Models directory ready at: $(pwd)/models"
log ""
log "  Download the LLM model (run manually):"
echo -e "  ${CYAN}wget -c https://huggingface.co/bartowski/Mistral-7B-Instruct-v0.3-GGUF/resolve/main/Mistral-7B-Instruct-v0.3-Q4_K_M.gguf -O models/mistral-7b-instruct-v0.3.Q4_K_M.gguf${NC}"

# ── 7. Build & start containers ───────────────────────────────────────────────
log "Building Docker containers..."
docker compose build --no-cache

log "Starting services..."
docker compose up -d postgres redis

log "Waiting for database to be ready..."
sleep 8
docker compose exec -T postgres psql -U ram -d ram -c "SELECT 1;" > /dev/null 2>&1 || {
    sleep 10
    docker compose exec -T postgres psql -U ram -d ram -c "SELECT 1;"
}
log "  ✓ PostgreSQL ready"

log "Running database migrations..."
docker compose run --rm backend python -m db.migrate
log "  ✓ Database schema applied"

log "Starting all services..."
docker compose up -d

# ── 8. Health check ───────────────────────────────────────────────────────────
sleep 5
HTTP_CODE=$(curl -sk -o /dev/null -w "%{http_code}" http://localhost:8000/health || echo "000")
if [[ "$HTTP_CODE" == "200" ]]; then
    log "  ✓ Backend API healthy"
else
    warn "  Backend returned HTTP $HTTP_CODE — check: docker compose logs backend"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
log ""
log "═══════════════════════════════════════════"
log "  RAM Phase 1 Setup Complete!"
log "═══════════════════════════════════════════"
log ""
log "  API:    http://localhost:8000"
log "  Docs:   http://localhost:8000/docs"
log "  Health: http://localhost:8000/health"
log ""
log "  Next steps:"
log "  1. Download the model (command above)"
log "  2. Start llama server: docker compose up -d llama_server"
log "  3. Register first user: POST /auth/register"
log ""
warn "  Remember to download the LLM model before using chat!"
